# flower classification

Classify the class of flowers in a picture. The classes include daisy, dandelion, roses, sunflowers and tulip.